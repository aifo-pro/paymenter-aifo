<?php

namespace Paymenter\Extensions\Gateways\Aifo;

use App\Classes\Extension\Gateway;
use App\Helpers\ExtensionHelper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\View;

class Aifo extends Gateway
{
    private const PAY_ENDPOINT = 'https://aifo.pro/pay/';
    private const CACHE_TTL_HOURS = 24;
    private const CACHE_VERSION = 'v2';

    public function boot()
    {
        require __DIR__ . '/routes/web.php';
        View::addNamespace('extensions.gateways.aifo', __DIR__ . '/views');
    }

    public function getConfig($values = [])
    {
        return [
            [
                'name' => 'shop_id',
                'label' => 'Shop ID',
                'description' => 'Checkout ID from AIFO.PRO merchant settings.',
                'type' => 'text',
                'required' => true,
            ],
            [
                'name' => 'secret_key',
                'label' => 'Secret key',
                'description' => 'Use kassa_secretkey from AIFO.PRO.',
                'type' => 'text',
                'required' => true,
            ],
            [
                'name' => 'signature_type',
                'label' => 'Signature type',
                'description' => '1=MD5, 2=SHA256, 3=SHA1, 4=RIPEMD160, 5=SHA384, 6=SHA512. Default: SHA256.',
                'type' => 'text',
                'required' => false,
            ],
            [
                'name' => 'pay_id_prefix',
                'label' => 'Optional pay_id prefix',
                'description' => 'Optional prefix for merchant invoice IDs. Example: order_123.',
                'type' => 'text',
                'required' => false,
            ],
            [
                'name' => 'numeric_pay_id_only',
                'label' => 'Legacy compatibility option',
                'description' => 'Kept for compatibility. The gateway now uses the Paymenter invoice ID by default.',
                'type' => 'checkbox',
                'required' => false,
            ],
        ];
    }

    protected function getShopId(): string
    {
        return trim((string) $this->config('shop_id'));
    }

    protected function getSecretKey(): string
    {
        return trim((string) $this->config('secret_key'));
    }

    protected function getSignatureType(): int
    {
        $signatureType = (int) $this->config('signature_type');

        return $signatureType >= 1 && $signatureType <= 6 ? $signatureType : 2;
    }

    protected function getPayIdPrefix(): string
    {
        $raw = trim((string) $this->config('pay_id_prefix'));

        return (string) preg_replace('/[^a-zA-Z0-9_-]/', '', $raw);
    }

    protected function buildPayId(int $paymenterInvoiceId): string
    {
        $prefix = $this->getPayIdPrefix();
        if ($prefix !== '') {
            return $prefix . $paymenterInvoiceId;
        }

        return (string) max(1, $paymenterInvoiceId);
    }

    protected function formatCheckoutAmount(float $amount): string
    {
        return number_format(round($amount, 2), 2, '.', '');
    }

    protected function hashSignString(string $signString, int $signatureType): string
    {
        return match ($signatureType) {
            1 => hash('md5', $signString),
            3 => hash('sha1', $signString),
            4 => hash('ripemd160', $signString),
            5 => hash('sha384', $signString),
            6 => hash('sha512', $signString),
            default => hash('sha256', $signString),
        };
    }

    protected function buildCheckoutSignature(string $shopId, string $formattedAmount, string $secretKey, string $payId): string
    {
        return $this->hashSignString(
            $shopId . ':' . $formattedAmount . ':' . $secretKey . ':' . $payId,
            $this->getSignatureType()
        );
    }

    protected function buildPayRedirectUrl(
        string $shopId,
        string $payId,
        string $formattedAmount,
        string $signature,
        ?string $description = null
    ): string {
        $query = [
            'shop_id' => $shopId,
            'pay_id' => $payId,
            'amount' => $formattedAmount,
            'sign' => $signature,
        ];

        $description = trim((string) $description);
        if ($description !== '') {
            $query['desc'] = $description;
        }

        return self::PAY_ENDPOINT . '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    }

    protected function getPaymenterInvoiceCacheKey(int $paymenterInvoiceId): string
    {
        return 'aifo:' . self::CACHE_VERSION . ':paymenter:' . $paymenterInvoiceId;
    }

    protected function getPayLookupCacheKey(string $payId): string
    {
        return 'aifo:' . self::CACHE_VERSION . ':pay:' . $payId;
    }

    protected function getProcessedCallbackCacheKey(string $payId): string
    {
        return 'aifo:' . self::CACHE_VERSION . ':processed:' . $payId;
    }

    protected function cachePaymentMapping(int $paymenterInvoiceId, string $payId, float $amount, string $paymentUrl): void
    {
        $payload = [
            'paymenter_invoice_id' => $paymenterInvoiceId,
            'pay_id' => $payId,
            'amount' => $amount,
            'payment_url' => $paymentUrl,
        ];

        $ttl = now()->addHours(self::CACHE_TTL_HOURS);

        Cache::put($this->getPaymenterInvoiceCacheKey($paymenterInvoiceId), $payload, $ttl);
        Cache::put($this->getPayLookupCacheKey($payId), $payload, $ttl);
    }

    protected function extractPayIdFromPaymentUrl(string $paymentUrl): string
    {
        $query = parse_url($paymentUrl, PHP_URL_QUERY);
        if (! is_string($query) || $query === '') {
            return '';
        }

        parse_str($query, $params);

        return trim((string) ($params['pay_id'] ?? ''));
    }

    protected function findCachedPaymentMappingByInvoice(int $paymenterInvoiceId, float $amount, string $expectedPayId): ?array
    {
        $cached = Cache::get($this->getPaymenterInvoiceCacheKey($paymenterInvoiceId));
        if (! is_array($cached)) {
            return null;
        }

        if (abs($amount - (float) ($cached['amount'] ?? 0.0)) > 0.02) {
            return null;
        }

        if (empty($cached['payment_url'])) {
            return null;
        }

        $cachedPayId = trim((string) ($cached['pay_id'] ?? ''));
        if ($cachedPayId === '') {
            $cachedPayId = $this->extractPayIdFromPaymentUrl((string) $cached['payment_url']);
        }

        if ($cachedPayId !== $expectedPayId) {
            Cache::forget($this->getPaymenterInvoiceCacheKey($paymenterInvoiceId));
            if ($cachedPayId !== '') {
                Cache::forget($this->getPayLookupCacheKey($cachedPayId));
            }

            return null;
        }

        return $cached;
    }

    protected function verifyCallbackSignature($sum, $invoice, ?string $providedSignature, string $secretKey, string $shopId): bool
    {
        if ($providedSignature === null || $providedSignature === '') {
            return false;
        }

        $invoice = trim((string) $invoice);
        if ($invoice === '') {
            return false;
        }

        $sumRaw = trim((string) $sum);
        $amountCandidates = array_values(array_unique(array_filter([
            $sumRaw,
            is_numeric($sum) ? (string) ((float) $sum) : null,
            is_numeric($sum) ? number_format((float) $sum, 2, '.', '') : null,
        ], static fn ($value) => $value !== null && $value !== '')));

        $signatureType = $this->getSignatureType();
        $types = array_values(array_unique(array_merge([$signatureType], [1, 2, 3, 4, 5, 6])));

        foreach ($amountCandidates as $amountCandidate) {
            foreach ($types as $type) {
                $expected = $this->hashSignString(
                    $shopId . ':' . $amountCandidate . ':' . $secretKey . ':' . $invoice,
                    $type
                );

                if (hash_equals($expected, $providedSignature)) {
                    return true;
                }
            }
        }

        return false;
    }

    protected function resolvePaymenterInvoiceIdFromPayId(?string $payId): ?int
    {
        $payId = trim((string) $payId);
        if ($payId === '') {
            return null;
        }

        $cached = Cache::get($this->getPayLookupCacheKey($payId));
        if (is_array($cached) && (int) ($cached['paymenter_invoice_id'] ?? 0) > 0) {
            return (int) $cached['paymenter_invoice_id'];
        }

        $prefix = $this->getPayIdPrefix();
        if ($prefix !== '' && str_starts_with($payId, $prefix)) {
            $suffix = substr($payId, strlen($prefix));
            if ($suffix !== '' && ctype_digit($suffix)) {
                return (int) $suffix;
            }
        }

        return ctype_digit($payId) ? (int) $payId : null;
    }

    protected function resolvePaymenterInvoiceIdFromSuccessRequest(Request $request): ?int
    {
        $orderReference = trim((string) $request->input('orderReference'));
        if ($orderReference !== '') {
            $resolved = $this->resolvePaymenterInvoiceIdFromPayId($orderReference);
            if ($resolved !== null && $resolved > 0) {
                return $resolved;
            }
        }

        $invoice = trim((string) $request->input('invoice'));
        if ($invoice !== '') {
            $cached = Cache::get($this->getPayLookupCacheKey($invoice));
            if (is_array($cached) && (int) ($cached['paymenter_invoice_id'] ?? 0) > 0) {
                return (int) $cached['paymenter_invoice_id'];
            }
        }

        $sessionInvoiceId = (int) Session::get('aifo:last_paymenter_invoice_id', 0);

        return $sessionInvoiceId > 0 ? $sessionInvoiceId : null;
    }

    public function pay($invoice, $total)
    {
        $shopId = $this->getShopId();
        $secretKey = $this->getSecretKey();
        $paymenterInvoiceId = (int) $invoice->id;
        $amount = round((float) $total, 2);

        if ($shopId === '' || $secretKey === '') {
            return view('extensions.gateways.aifo::error', [
                'error' => 'AIFO: configure Shop ID and Secret key in the gateway settings.',
            ]);
        }

        if ((int) $shopId < 1) {
            return view('extensions.gateways.aifo::error', [
                'error' => 'AIFO: invalid Shop ID.',
            ]);
        }

        $payId = $this->buildPayId($paymenterInvoiceId);
        Session::put('aifo:last_paymenter_invoice_id', $paymenterInvoiceId);
        Session::put('aifo:last_pay_id', $payId);

        $cached = $this->findCachedPaymentMappingByInvoice($paymenterInvoiceId, $amount, $payId);
        if ($cached !== null) {
            return view('extensions.gateways.aifo::pay', [
                'paymentUrl' => $cached['payment_url'],
            ]);
        }

        $formattedAmount = $this->formatCheckoutAmount($amount);
        $description = 'Payment';
        $signature = $this->buildCheckoutSignature($shopId, $formattedAmount, $secretKey, $payId);
        $paymentUrl = $this->buildPayRedirectUrl($shopId, $payId, $formattedAmount, $signature, $description);

        $this->cachePaymentMapping($paymenterInvoiceId, $payId, $amount, $paymentUrl);

        return view('extensions.gateways.aifo::pay', [
            'paymentUrl' => $paymentUrl,
        ]);
    }

    public function result(Request $request)
    {
        $shopId = $this->getShopId();
        $secretKey = $this->getSecretKey();
        $sum = $request->input('sum');
        $payId = trim((string) $request->input('invoice'));
        $signature = $request->input('http_auth_signature');

        Log::info('AIFO result callback received', [
            'invoice' => $payId,
            'sum' => $sum,
            'has_signature' => is_string($signature) && $signature !== '',
            'ip' => $request->ip(),
        ]);

        if ($shopId === '' || $secretKey === '') {
            Log::warning('AIFO result callback rejected: gateway not configured');

            return response('Gateway not configured', 500);
        }

        if (! $this->verifyCallbackSignature($sum, $payId, is_string($signature) ? $signature : null, $secretKey, $shopId)) {
            Log::warning('AIFO result callback rejected: invalid signature', [
                'invoice' => $payId,
                'sum' => $sum,
            ]);

            return response('Invalid signature', 401);
        }

        $paymenterInvoiceId = $this->resolvePaymenterInvoiceIdFromPayId($payId);
        if ($paymenterInvoiceId === null || $paymenterInvoiceId < 1) {
            Log::warning('AIFO result callback rejected: invoice not found', [
                'invoice' => $payId,
            ]);

            return response('Invoice not found', 404);
        }

        $cached = Cache::get($this->getPayLookupCacheKey($payId));
        if (is_array($cached) && isset($cached['amount']) && is_numeric($sum)) {
            if (abs((float) $sum - (float) $cached['amount']) > 0.02) {
                Log::warning('AIFO result callback rejected: amount mismatch', [
                    'invoice' => $payId,
                    'expected' => $cached['amount'],
                    'received' => $sum,
                ]);

                return response('Amount mismatch', 400);
            }
        }

        if (! Cache::add($this->getProcessedCallbackCacheKey($payId), 1, now()->addHours(self::CACHE_TTL_HOURS))) {
            Log::info('AIFO result callback skipped: already processed', [
                'invoice' => $payId,
                'paymenter_invoice_id' => $paymenterInvoiceId,
            ]);

            return response('OK', 200);
        }

        try {
            ExtensionHelper::addPayment($paymenterInvoiceId, 'AIFO', (float) $sum, null, $payId);
            Log::info('AIFO payment applied', [
                'invoice' => $payId,
                'paymenter_invoice_id' => $paymenterInvoiceId,
                'sum' => $sum,
            ]);
        } catch (\Throwable $e) {
            Cache::forget($this->getProcessedCallbackCacheKey($payId));
            Log::error('AIFO payment processing failed', [
                'invoice' => $payId,
                'paymenter_invoice_id' => $paymenterInvoiceId,
                'error' => $e->getMessage(),
            ]);

            return response('Payment processing failed: ' . $e->getMessage(), 500);
        }

        return response('OK', 200);
    }

    public function returnSuccess(Request $request)
    {
        $paymenterInvoiceId = $this->resolvePaymenterInvoiceIdFromSuccessRequest($request);

        if ($paymenterInvoiceId === null || $paymenterInvoiceId < 1) {
            return redirect()->route('dashboard');
        }

        return redirect()
            ->route('invoices.show', ['invoice' => $paymenterInvoiceId])
            ->with('success', 'Payment page returned successfully. Waiting for AIFO callback confirmation.');
    }

    public function returnCancel(Request $request)
    {
        $paymenterInvoiceId = $this->resolvePaymenterInvoiceIdFromSuccessRequest($request);

        if ($paymenterInvoiceId === null || $paymenterInvoiceId < 1) {
            return redirect()->route('dashboard');
        }

        return redirect()
            ->route('invoices.show', ['invoice' => $paymenterInvoiceId])
            ->with('error', 'Payment was cancelled or not completed.');
    }
}
