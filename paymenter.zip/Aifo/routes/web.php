<?php

use App\Http\Middleware\VerifyCsrfToken;
use Illuminate\Support\Facades\Route;
use Paymenter\Extensions\Gateways\Aifo\Aifo;

Route::post('/extensions/gateways/aifo/result', [Aifo::class, 'result'])
    ->withoutMiddleware([VerifyCsrfToken::class])
    ->name('extensions.gateways.aifo.result');

Route::match(['get', 'post'], '/extensions/gateways/aifo/success', [Aifo::class, 'returnSuccess'])
    ->name('extensions.gateways.aifo.success');

Route::match(['get', 'post'], '/extensions/gateways/aifo/cancel', [Aifo::class, 'returnCancel'])
    ->name('extensions.gateways.aifo.cancel');
