@assets
@endassets

@script
<script>
    window.location.replace(@json($paymentUrl));
</script>
@endscript

<body class="min-h-screen flex items-center justify-center p-8">
    <p class="text-center text-gray-600">
        Перенаправлення на оплату AIFO…
        <a href="{{ $paymentUrl }}" class="underline text-blue-600">Натисніть тут</a>, якщо не відбулося автоматично.
    </p>
</body>
