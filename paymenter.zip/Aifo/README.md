# AIFO Gateway for Paymenter

This module is now aligned with the actual AIFO.PRO service source code.

## How it works

The gateway uses the direct checkout page:

`https://aifo.pro/pay/?shop_id=...&pay_id=...&amount=...&sign=...&desc=...`

Important implementation details taken from the AIFO.PRO source:

- `/pay/` validates the signature using the amount formatted as `0.00`
- the callback to the merchant `result_url` sends:
  - `sum`
  - `invoice`
  - `http_auth_signature`
- the callback uses the merchant invoice ID (`invoice_uid`), not the internal AIFO `invoice_id`
- `success_url` and `error_url` are browser redirects only and should not be used as the payment confirmation source

## Required AIFO settings

Set these URLs in your AIFO merchant panel:

- Result URL: `https://YOUR-DOMAIN/extensions/gateways/aifo/result`
- Success URL: `https://YOUR-DOMAIN/extensions/gateways/aifo/success`
- Fail URL: `https://YOUR-DOMAIN/extensions/gateways/aifo/cancel`

## Gateway settings

- `Shop ID`
- `Secret key`
- `Signature type`
- `Optional pay_id prefix`

## Notes

- By default `pay_id` is the Paymenter invoice ID.
- If a prefix is configured, the gateway sends `prefix + invoice_id`.
- Payment confirmation is processed through the `result` route, not through the success redirect.
